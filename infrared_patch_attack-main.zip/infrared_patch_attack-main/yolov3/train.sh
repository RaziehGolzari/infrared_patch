nohup python train.py --img 416 --batch 16 --epochs 100 --data pedestrain.yaml --weights yolov3.pt > train_log.txt &
